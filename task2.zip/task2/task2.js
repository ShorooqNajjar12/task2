function restartAnimation() {
    var ball = document.getElementById('ball');
    ball.style.animation = 'none';
    void ball.offsetWidth; // Trigger reflow
    ball.style.animation = 'bounce 4s ease-in-out infinite'; /* Adjusted duration */
  }
  